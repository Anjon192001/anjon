"use client"

import { useState, useEffect } from "react"

type ToastProps = {
  title: string
  description?: string
  variant?: "default" | "destructive" | "success"
  duration?: number
}

type Toast = ToastProps & {
  id: string
  visible: boolean
}

export function useToast() {
  const [toasts, setToasts] = useState<Toast[]>([])

  useEffect(() => {
    const timers: NodeJS.Timeout[] = []

    toasts.forEach((toast) => {
      if (toast.visible) {
        const timer = setTimeout(() => {
          setToasts((prevToasts) => prevToasts.map((t) => (t.id === toast.id ? { ...t, visible: false } : t)))
        }, toast.duration || 3000)

        timers.push(timer)
      }
    })

    return () => {
      timers.forEach((timer) => clearTimeout(timer))
    }
  }, [toasts])

  // Clean up invisible toasts after animation
  useEffect(() => {
    const invisibleToasts = toasts.filter((t) => !t.visible)
    if (invisibleToasts.length > 0) {
      const timer = setTimeout(() => {
        setToasts((prevToasts) => prevToasts.filter((t) => t.visible))
      }, 300) // Animation duration

      return () => clearTimeout(timer)
    }
  }, [toasts])

  const toast = (props: ToastProps) => {
    const id = Math.random().toString(36).substring(2, 9)
    setToasts((prevToasts) => [
      ...prevToasts,
      {
        id,
        visible: true,
        variant: "default",
        duration: 3000,
        ...props,
      },
    ])
  }

  const dismiss = (id: string) => {
    setToasts((prevToasts) => prevToasts.map((t) => (t.id === id ? { ...t, visible: false } : t)))
  }

  return { toast, dismiss, toasts }
}

// Export a singleton instance for global use
const toastState = {
  toasts: [] as Toast[],
  toast: (props: ToastProps) => {
    // This will be replaced with the actual implementation
    console.log("Toast:", props)
  },
  dismiss: (id: string) => {
    // This will be replaced with the actual implementation
    console.log("Dismiss toast:", id)
  },
}

// For use in components that can't use hooks
export const toast = (props: ToastProps) => {
  toastState.toast(props)
}

export default useToast


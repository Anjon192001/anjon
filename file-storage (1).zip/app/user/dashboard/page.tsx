"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { UserDashboard } from "@/components/user-dashboard"

export default function UserDashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser")

    if (!currentUser) {
      router.push("/")
      return
    }

    setLoading(false)
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  return <UserDashboard />
}


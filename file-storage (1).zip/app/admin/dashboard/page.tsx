"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AdminDashboard } from "@/components/admin-dashboard"

export default function AdminDashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in and is an admin
    const currentUser = localStorage.getItem("currentUser")

    if (!currentUser) {
      router.push("/")
      return
    }

    const user = JSON.parse(currentUser)
    if (user.role !== "admin") {
      router.push("/")
      return
    }

    setLoading(false)
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  return <AdminDashboard />
}


"use client"

import { useState } from "react"
import { File, Folder, Grid, List, Search, Upload, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileCard } from "@/components/file-card"
import { FileList } from "@/components/file-list"
import { UploadDialog } from "@/components/upload-dialog"

// Sample data for demonstration
const initialFiles = [
  {
    id: "1",
    name: "Project Documentation.pdf",
    type: "pdf",
    size: "2.4 MB",
    modified: "2023-10-15",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "2",
    name: "Company Logo.png",
    type: "image",
    size: "1.2 MB",
    modified: "2023-10-14",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "3",
    name: "Quarterly Report.xlsx",
    type: "spreadsheet",
    size: "3.5 MB",
    modified: "2023-10-12",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "4",
    name: "Team Photo.jpg",
    type: "image",
    size: "4.2 MB",
    modified: "2023-10-10",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "5",
    name: "Product Presentation.pptx",
    type: "presentation",
    size: "5.7 MB",
    modified: "2023-10-08",
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
]

const folders = [
  {
    id: "f1",
    name: "Documents",
    files: 12,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "f2",
    name: "Images",
    files: 24,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "f3",
    name: "Projects",
    files: 8,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
]

export function FileStorage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [files, setFiles] = useState(initialFiles)
  const [isUploadOpen, setIsUploadOpen] = useState(false)

  // Filter files based on search query
  const filteredFiles = files.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const filteredFolders = folders.filter((folder) => folder.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleUpload = (newFile: any) => {
    setFiles((prev) => [...prev, newFile])
    setIsUploadOpen(false)
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <header className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-2xl font-bold">File Storage</h1>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search files and folders..."
              className="pl-8 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Button onClick={() => setIsUploadOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Folder className="mr-2 h-4 w-4" />
                New Folder
              </DropdownMenuItem>
              <DropdownMenuItem>
                <File className="mr-2 h-4 w-4" />
                New File
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <Tabs defaultValue="grid">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="grid">
              <Grid className="h-4 w-4 mr-2" />
              Grid
            </TabsTrigger>
            <TabsTrigger value="list">
              <List className="h-4 w-4 mr-2" />
              List
            </TabsTrigger>
          </TabsList>

          <div className="text-sm text-muted-foreground">
            {filteredFiles.length} files, {filteredFolders.length} folders
          </div>
        </div>

        <TabsContent value="grid" className="mt-6">
          {filteredFolders.length > 0 && (
            <div>
              <h2 className="text-lg font-medium mb-4">Folders</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredFolders.map((folder) => (
                  <FileCard
                    key={folder.id}
                    name={folder.name}
                    type="folder"
                    thumbnail={folder.thumbnail}
                    metadata={`${folder.files} files`}
                  />
                ))}
              </div>
            </div>
          )}

          {filteredFiles.length > 0 && (
            <div className="mt-8">
              <h2 className="text-lg font-medium mb-4">Files</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredFiles.map((file) => (
                  <FileCard
                    key={file.id}
                    name={file.name}
                    type={file.type}
                    thumbnail={file.thumbnail}
                    metadata={file.size}
                  />
                ))}
              </div>
            </div>
          )}

          {filteredFiles.length === 0 && filteredFolders.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No files or folders found</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="list">
          {filteredFolders.length > 0 && (
            <div>
              <h2 className="text-lg font-medium mb-4">Folders</h2>
              <FileList
                items={filteredFolders.map((folder) => ({
                  id: folder.id,
                  name: folder.name,
                  type: "folder",
                  size: `${folder.files} files`,
                  modified: "-",
                }))}
              />
            </div>
          )}

          {filteredFiles.length > 0 && (
            <div className="mt-8">
              <h2 className="text-lg font-medium mb-4">Files</h2>
              <FileList
                items={filteredFiles.map((file) => ({
                  id: file.id,
                  name: file.name,
                  type: file.type,
                  size: file.size,
                  modified: file.modified,
                }))}
              />
            </div>
          )}

          {filteredFiles.length === 0 && filteredFolders.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No files or folders found</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <UploadDialog open={isUploadOpen} onOpenChange={setIsUploadOpen} onUpload={handleUpload} />
    </div>
  )
}


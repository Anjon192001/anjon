"use client"

import type React from "react"

import { useState } from "react"
import { Upload } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface UploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpload: (file: any) => void
}

export function UploadDialog({ open, onOpenChange, onUpload }: UploadDialogProps) {
  const [fileName, setFileName] = useState("")
  const [fileType, setFileType] = useState("image")
  const [fileSize, setFileSize] = useState("0 KB")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      setFileName(file.name)

      // Determine file type
      if (file.type.includes("image")) {
        setFileType("image")
      } else if (file.type.includes("pdf")) {
        setFileType("pdf")
      } else if (file.type.includes("spreadsheet") || file.name.endsWith(".xlsx") || file.name.endsWith(".xls")) {
        setFileType("spreadsheet")
      } else if (file.type.includes("presentation") || file.name.endsWith(".pptx") || file.name.endsWith(".ppt")) {
        setFileType("presentation")
      } else {
        setFileType("file")
      }

      // Format file size
      const size = file.size
      if (size < 1024) {
        setFileSize(`${size} B`)
      } else if (size < 1024 * 1024) {
        setFileSize(`${(size / 1024).toFixed(1)} KB`)
      } else {
        setFileSize(`${(size / (1024 * 1024)).toFixed(1)} MB`)
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (fileName) {
      const newFile = {
        id: Date.now().toString(),
        name: fileName,
        type: fileType,
        size: fileSize,
        modified: new Date().toISOString().split("T")[0],
        thumbnail: "/placeholder.svg?height=80&width=80",
      }

      onUpload(newFile)
      resetForm()
    }
  }

  const resetForm = () => {
    setFileName("")
    setFileType("image")
    setFileSize("0 KB")
    setSelectedFile(null)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
        if (!open) resetForm()
      }}
    >
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Upload File</DialogTitle>
            <DialogDescription>
              Upload a file to your storage. Supported formats include images, documents, and more.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="file">File</Label>
              <div className="flex items-center gap-2">
                <Input id="file" type="file" onChange={handleFileChange} className="flex-1" />
              </div>
            </div>

            {selectedFile && (
              <div className="grid gap-2">
                <Label>File Details</Label>
                <div className="text-sm">
                  <p>
                    <strong>Name:</strong> {fileName}
                  </p>
                  <p>
                    <strong>Type:</strong> {fileType}
                  </p>
                  <p>
                    <strong>Size:</strong> {fileSize}
                  </p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!selectedFile}>
              <Upload className="mr-2 h-4 w-4" />
              Upload
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


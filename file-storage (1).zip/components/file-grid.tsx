"use client"

import { Download, Edit, Eye, File, Folder, MoreVertical, Trash } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { FileViewDialog } from "@/components/file-view-dialog"
import { FileEditDialog } from "@/components/file-edit-dialog"
import { Badge } from "@/components/ui/badge"

interface FileGridProps {
  files: any[]
  folders?: any[]
  onDelete?: (id: string) => void
  onEdit?: (file: any) => void
  isAdmin: boolean
  onFolderClick?: (id: string, name: string) => void
}

export function FileGrid({ files, folders = [], onDelete, onEdit, isAdmin, onFolderClick }: FileGridProps) {
  const [viewFile, setViewFile] = useState<any | null>(null)
  const [editFile, setEditFile] = useState<any | null>(null)

  // Handle download functionality
  const handleDownload = (file: any) => {
    // Create a link element
    const link = document.createElement("a")

    // In a real app, this would be the actual file URL
    // For this demo, we'll use the placeholder image or the file's thumbnail
    link.href = file.thumbnail || "/placeholder.svg?height=800&width=600&text=Certificate"

    // Set the download attribute with the file name
    link.download = file.name

    // Append to the document
    document.body.appendChild(link)

    // Trigger the download
    link.click()

    // Clean up
    document.body.removeChild(link)
  }

  const handleEditSubmit = (editedFile: any) => {
    if (onEdit) {
      onEdit(editedFile)
    }
    setEditFile(null)
  }

  if (files.length === 0 && folders.length === 0) {
    return (
      <div className="text-center py-12">
        <File className="mx-auto h-12 w-12 text-muted-foreground" />
        <h3 className="mt-4 text-lg font-medium">No files found</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          {isAdmin ? "Upload some files to get started." : "There are no files available for you to view."}
        </p>
      </div>
    )
  }

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {/* Render folders first */}
        {folders.map((folder) => (
          <Card
            key={folder.id}
            className="glass-card hover-lift overflow-hidden rounded-xl border-0 transform transition-all duration-300 hover:scale-105"
            onClick={() => onFolderClick?.(folder.id, folder.name)}
          >
            <div className="aspect-[4/3] bg-gradient-to-br from-primary/5 to-primary/20 flex items-center justify-center p-4 relative">
              <div className="absolute inset-0 flex items-center justify-center opacity-10">
                <img
                  src="/placeholder.svg?height=300&width=200&text=Folder"
                  alt={folder.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <Folder className="h-24 w-24 text-primary opacity-80" />
            </div>
            <CardContent className="p-5">
              <div className="space-y-1">
                <h3 className="font-medium truncate" title={folder.name}>
                  {folder.name}
                </h3>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 rounded-lg">
                    {folder.category}
                  </Badge>
                  <p className="text-xs text-muted-foreground">
                    {folder.count} {folder.count === 1 ? "certificate" : "certificates"}
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="p-5 pt-0">
              <Button variant="outline" size="sm" className="w-full rounded-lg">
                <Folder className="mr-2 h-4 w-4" />
                Open Folder
              </Button>
            </CardFooter>
          </Card>
        ))}

        {/* Then render files */}
        {files.map((file) => (
          <Card
            key={file.id}
            className="glass-card hover-lift overflow-hidden rounded-xl border-0 transform transition-all duration-300 hover:scale-105"
          >
            <div className="aspect-[4/3] bg-white flex items-center justify-center p-4 certificate-frame">
              {file.type === "image" ? (
                <img
                  src={file.thumbnail || "/placeholder.svg?height=300&width=200&text=Image"}
                  alt={file.name}
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <img
                  src="/placeholder.svg?height=300&width=200&text=Certificate"
                  alt={file.name}
                  className="max-w-full max-h-full object-contain"
                />
              )}
            </div>
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <h3 className="font-medium truncate" title={file.name}>
                    {file.fullName}
                  </h3>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 rounded-lg">
                      {file.category}
                    </Badge>
                    <p className="text-xs text-muted-foreground">{file.formattedDate || file.uploadedAt}</p>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                      <MoreVertical className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="rounded-xl">
                    <DropdownMenuItem onClick={() => setViewFile(file)} className="cursor-pointer">
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDownload(file)} className="cursor-pointer">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </DropdownMenuItem>

                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setEditFile(file)} className="cursor-pointer">
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive cursor-pointer"
                          onClick={() => onDelete?.(file.id)}
                        >
                          <Trash className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardContent>
            <CardFooter className="p-5 pt-0">
              <Button
                variant="outline"
                size="sm"
                className="w-full rounded-lg hover:bg-primary hover:text-white transition-colors"
                onClick={() => setViewFile(file)}
              >
                <Eye className="mr-2 h-4 w-4" />
                View Certificate
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {viewFile && <FileViewDialog file={viewFile} open={!!viewFile} onOpenChange={() => setViewFile(null)} />}

      {editFile && (
        <FileEditDialog
          file={editFile}
          open={!!editFile}
          onOpenChange={() => setEditFile(null)}
          onEdit={handleEditSubmit}
        />
      )}
    </>
  )
}


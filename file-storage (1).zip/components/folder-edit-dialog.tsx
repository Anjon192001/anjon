"use client"

import type React from "react"

import { useState } from "react"
import { Save } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface FolderEditDialogProps {
  folder: any
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (folder: any) => void
}

export function FolderEditDialog({ folder, open, onOpenChange, onSave }: FolderEditDialogProps) {
  const [folderName, setFolderName] = useState(folder.name)
  const [folderCategory, setFolderCategory] = useState(folder.category)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (folderName && folderCategory) {
      const updatedFolder = {
        ...folder,
        name: folderName,
        category: folderCategory,
      }

      onSave(updatedFolder)
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Edit Folder</DialogTitle>
            <DialogDescription>Update folder information.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-folder-name">Folder Name</Label>
              <Input
                id="edit-folder-name"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-folder-category">Category</Label>
              <Select value={folderCategory} onValueChange={setFolderCategory} required>
                <SelectTrigger id="edit-folder-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="birth">Birth Certificates</SelectItem>
                  <SelectItem value="marriage">Marriage Certificates</SelectItem>
                  <SelectItem value="death">Death Certificates</SelectItem>
                  <SelectItem value="other">Other Documents</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import {
  User,
  Camera,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Save,
  X,
  Check,
  AlertCircle,
  SettingsIcon,
  Eye,
  EyeOff,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface UserProfileProps {
  username: string
  role: string
}

export function UserProfile({ username, role }: UserProfileProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [profileImage, setProfileImage] = useState<string | null>(
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Profile%20picture.jpg-pBicBaxJ72zxuCcxpTiAMOVxyOMk9m.jpeg",
  )
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [saveProgress, setSaveProgress] = useState(0)
  const [isSaving, setIsSaving] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")
  const [passwordStrength, setPasswordStrength] = useState(0)
  const [passwordVisible, setPasswordVisible] = useState(false)

  const [formData, setFormData] = useState({
    fullName: "MARIO S SABINO JR",
    email: "mariobaldo2001@gmail.com",
    phone: "09756419201",
    address: "p-6 kisolon sumilao bukidnon",
    bio: "",
    birthdate: "2001-04-19",
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    browser: true,
    updates: true,
    securityAlerts: true,
  })

  const [appearance, setAppearance] = useState({
    darkMode: false,
    compactMode: false,
    highContrast: false,
    fontSize: "medium",
  })

  const [privacy, setPrivacy] = useState({
    profileVisibility: "public",
    activityStatus: true,
    dataSharing: false,
  })

  // Simulate loading user data
  useEffect(() => {
    const timer = setTimeout(() => {
      // This would be a fetch call in a real app
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const result = reader.result as string
        setPreviewImage(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveImage = () => {
    setIsSaving(true)
    setSaveProgress(0)

    // Simulate progress
    const interval = setInterval(() => {
      setSaveProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setProfileImage(previewImage)
            setPreviewImage(null)
            setIsSaving(false)
            toast({
              title: "Profile picture updated",
              description: "Your profile picture has been successfully updated.",
            })
          }, 500)
          return 100
        }
        return prev + 10
      })
    }, 100)
  }

  const handleCancelImage = () => {
    setPreviewImage(null)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPasswordData({
      ...passwordData,
      [name]: value,
    })

    // Calculate password strength if changing new password
    if (name === "newPassword") {
      let strength = 0
      if (value.length > 0) strength += 20
      if (value.length >= 8) strength += 20
      if (/[A-Z]/.test(value)) strength += 20
      if (/[0-9]/.test(value)) strength += 20
      if (/[^A-Za-z0-9]/.test(value)) strength += 20
      setPasswordStrength(strength)
    }
  }

  const handleSaveProfile = () => {
    setIsSaving(true)
    setSaveProgress(0)

    // Simulate progress
    const interval = setInterval(() => {
      setSaveProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setIsEditing(false)
            setIsSaving(false)
            setShowSuccess(true)
            setTimeout(() => setShowSuccess(false), 3000)
            toast({
              title: "Profile updated",
              description: "Your profile information has been successfully updated.",
            })
          }, 500)
          return 100
        }
        return prev + 5
      })
    }, 50)
  }

  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "New password and confirmation password must match.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    setSaveProgress(0)

    // Simulate progress
    const interval = setInterval(() => {
      setSaveProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setIsSaving(false)
            setPasswordData({
              currentPassword: "",
              newPassword: "",
              confirmPassword: "",
            })
            setPasswordStrength(0)
            toast({
              title: "Password changed",
              description: "Your password has been successfully updated.",
            })
          }, 500)
          return 100
        }
        return prev + 5
      })
    }, 50)
  }

  const handleNotificationChange = (key: keyof typeof notifications) => {
    setNotifications({
      ...notifications,
      [key]: !notifications[key],
    })

    toast({
      title: "Settings updated",
      description: `${key.charAt(0).toUpperCase() + key.slice(1)} notifications ${!notifications[key] ? "enabled" : "disabled"}.`,
    })
  }

  const handleAppearanceChange = (key: keyof typeof appearance, value: any) => {
    setAppearance({
      ...appearance,
      [key]: value,
    })

    toast({
      title: "Appearance updated",
      description: `${
        key.charAt(0).toUpperCase() +
        key
          .slice(1)
          .replace(/([A-Z])/g, " $1")
          .toLowerCase()
      } has been updated.`,
    })
  }

  const handlePrivacyChange = (key: keyof typeof privacy, value: any) => {
    setPrivacy({
      ...privacy,
      [key]: value,
    })

    toast({
      title: "Privacy settings updated",
      description: `Your privacy settings have been updated.`,
    })
  }

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 40) return "bg-destructive"
    if (passwordStrength < 80) return "bg-yellow-500"
    return "bg-green-500"
  }

  return (
    <Card
      className={cn(
        "glass-card border-0 rounded-2xl transition-all duration-500",
        activeTab === "profile" ? "profile-card" : "settings-card",
      )}
    >
      <Tabs defaultValue="profile" onValueChange={setActiveTab}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="gradient-text text-2xl">User Profile</CardTitle>
            <TabsList className="rounded-xl">
              <TabsTrigger value="profile" className="rounded-lg">
                <User className="h-4 w-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="settings" className="rounded-lg">
                <SettingsIcon className="h-4 w-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>
          </div>
          <CardDescription>Manage your personal information and preferences</CardDescription>
        </CardHeader>

        <CardContent>
          <TabsContent value="profile" className="space-y-6 animate-in fade-in-50 duration-300">
            {showSuccess && (
              <Alert className="bg-green-50 text-green-800 border-green-200 animate-in slide-in-from-top duration-300">
                <Check className="h-4 w-4 text-green-600" />
                <AlertTitle>Success!</AlertTitle>
                <AlertDescription>Your profile has been updated successfully.</AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative">
                  <Avatar className="w-32 h-32 border-4 border-primary/20 hover-lift">
                    <AvatarImage src={profileImage || "/placeholder.svg?height=128&width=128"} />
                    <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                      {username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute bottom-0 right-0 rounded-full bg-background shadow-md hover:bg-primary hover:text-white transition-colors duration-300"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Camera className="h-4 w-4" />
                    <span className="sr-only">Change profile picture</span>
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                </div>

                {previewImage && (
                  <div className="space-y-2 animate-in fade-in-50 duration-300">
                    <div className="relative w-32 h-32 border rounded-full overflow-hidden">
                      <img
                        src={previewImage || "/placeholder.svg"}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {isSaving ? (
                      <div className="w-full space-y-2">
                        <Progress value={saveProgress} className="h-2 w-full" />
                        <p className="text-xs text-center text-muted-foreground">Saving...</p>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <Button size="sm" onClick={handleSaveImage} className="w-full">
                          <Save className="h-3 w-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={handleCancelImage} className="w-full">
                          <X className="h-3 w-3 mr-1" />
                          Cancel
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                <div className="text-center">
                  <p className="font-medium text-lg">{username}</p>
                  <p className="text-sm text-muted-foreground capitalize">{role}</p>
                </div>
              </div>

              <Separator className="md:hidden" />

              <div className="flex-1 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Personal Information</h3>
                  <Button
                    variant={isEditing ? "outline" : "default"}
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                    className="transition-all duration-300 hover:scale-105"
                    disabled={isSaving}
                  >
                    {isEditing ? "Cancel" : "Edit"}
                  </Button>
                </div>

                {isEditing ? (
                  <div className="space-y-4 animate-in fade-in-50 duration-300">
                    <div className="grid gap-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="address">Address</Label>
                      <Input
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="birthdate">Birthdate</Label>
                      <Input
                        id="birthdate"
                        name="birthdate"
                        type="date"
                        value={formData.birthdate}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        name="bio"
                        rows={3}
                        value={formData.bio}
                        onChange={handleInputChange}
                        className="transition-all duration-300 focus:ring-2 focus:ring-primary focus:ring-offset-2"
                      />
                    </div>

                    {isSaving ? (
                      <div className="space-y-2">
                        <Progress value={saveProgress} className="h-2 w-full" />
                        <p className="text-xs text-center text-muted-foreground">Saving changes...</p>
                      </div>
                    ) : (
                      <Button
                        onClick={handleSaveProfile}
                        className="transition-all duration-300 hover:scale-105 button-3d"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4 animate-in fade-in-50 duration-300">
                    <div className="flex items-start gap-2 hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <User className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Full Name</p>
                        <p className="text-sm text-muted-foreground">{formData.fullName}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <Mail className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Email</p>
                        <p className="text-sm text-muted-foreground">{formData.email}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <Phone className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Phone</p>
                        <p className="text-sm text-muted-foreground">{formData.phone}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <MapPin className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Address</p>
                        <p className="text-sm text-muted-foreground">{formData.address}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <Calendar className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Birthdate</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(formData.birthdate).toLocaleDateString("en-US", {
                            month: "long",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>

                    <Separator />

                    <div className="hover:bg-muted/50 p-2 rounded-md transition-colors duration-200">
                      <p className="text-sm font-medium mb-2">Bio</p>
                      <p className="text-sm text-muted-foreground">{formData.bio}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 animate-in fade-in-50 duration-300">
            <div className="grid gap-6">
              {/* Security Settings */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Security Settings</h3>

                <div className="space-y-4 bg-muted/30 p-4 rounded-xl">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type={passwordVisible ? "text" : "password"}
                        value={passwordData.currentPassword}
                        onChange={handlePasswordChange}
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setPasswordVisible(!passwordVisible)}
                      >
                        {passwordVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={passwordData.newPassword}
                      onChange={handlePasswordChange}
                    />
                    {passwordData.newPassword && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Password strength</span>
                          <span>{passwordStrength >= 80 ? "Strong" : passwordStrength >= 40 ? "Medium" : "Weak"}</span>
                        </div>
                        <Progress value={passwordStrength} className={cn("h-1", getPasswordStrengthColor())} />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={passwordData.confirmPassword}
                      onChange={handlePasswordChange}
                    />
                    {passwordData.newPassword &&
                      passwordData.confirmPassword &&
                      passwordData.newPassword !== passwordData.confirmPassword && (
                        <p className="text-xs text-destructive flex items-center mt-1">
                          <AlertCircle className="h-3 w-3 mr-1" /> Passwords don't match
                        </p>
                      )}
                  </div>

                  {isSaving ? (
                    <div className="space-y-2">
                      <Progress value={saveProgress} className="h-2 w-full" />
                      <p className="text-xs text-center text-muted-foreground">Updating password...</p>
                    </div>
                  ) : (
                    <Button
                      onClick={handleChangePassword}
                      disabled={
                        !passwordData.currentPassword ||
                        !passwordData.newPassword ||
                        !passwordData.confirmPassword ||
                        passwordData.newPassword !== passwordData.confirmPassword
                      }
                      className="w-full transition-all duration-300 hover:scale-105"
                    >
                      Change Password
                    </Button>
                  )}
                </div>
              </div>

              {/* Notification Settings */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notification Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Email Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                    </div>
                    <Switch
                      checked={notifications.email}
                      onCheckedChange={() => handleNotificationChange("email")}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">SMS Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
                    </div>
                    <Switch
                      checked={notifications.sms}
                      onCheckedChange={() => handleNotificationChange("sms")}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Browser Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive notifications in browser</p>
                    </div>
                    <Switch
                      checked={notifications.browser}
                      onCheckedChange={() => handleNotificationChange("browser")}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">System Updates</p>
                      <p className="text-sm text-muted-foreground">Receive notifications about system updates</p>
                    </div>
                    <Switch
                      checked={notifications.updates}
                      onCheckedChange={() => handleNotificationChange("updates")}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Security Alerts</p>
                      <p className="text-sm text-muted-foreground">Receive notifications about security issues</p>
                    </div>
                    <Switch
                      checked={notifications.securityAlerts}
                      onCheckedChange={() => handleNotificationChange("securityAlerts")}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>
                </div>
              </div>

              {/* Appearance Settings */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Appearance Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Dark Mode</p>
                      <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                    </div>
                    <Switch
                      checked={appearance.darkMode}
                      onCheckedChange={(checked) => handleAppearanceChange("darkMode", checked)}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Compact Mode</p>
                      <p className="text-sm text-muted-foreground">Use a more compact interface layout</p>
                    </div>
                    <Switch
                      checked={appearance.compactMode}
                      onCheckedChange={(checked) => handleAppearanceChange("compactMode", checked)}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">High Contrast</p>
                      <p className="text-sm text-muted-foreground">Increase contrast for better visibility</p>
                    </div>
                    <Switch
                      checked={appearance.highContrast}
                      onCheckedChange={(checked) => handleAppearanceChange("highContrast", checked)}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="space-y-2 hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <Label htmlFor="fontSize">Font Size</Label>
                    <Select
                      value={appearance.fontSize}
                      onValueChange={(value) => handleAppearanceChange("fontSize", value)}
                    >
                      <SelectTrigger id="fontSize">
                        <SelectValue placeholder="Select font size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Privacy Settings */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Privacy Settings</h3>
                <div className="space-y-4">
                  <div className="space-y-2 hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <Label htmlFor="profileVisibility">Profile Visibility</Label>
                    <Select
                      value={privacy.profileVisibility}
                      onValueChange={(value) => handlePrivacyChange("profileVisibility", value)}
                    >
                      <SelectTrigger id="profileVisibility">
                        <SelectValue placeholder="Select visibility" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                        <SelectItem value="contacts">Contacts Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Activity Status</p>
                      <p className="text-sm text-muted-foreground">Show when you're active</p>
                    </div>
                    <Switch
                      checked={privacy.activityStatus}
                      onCheckedChange={(checked) => handlePrivacyChange("activityStatus", checked)}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>

                  <div className="flex items-center justify-between hover:bg-muted/30 p-3 rounded-lg transition-all duration-200">
                    <div>
                      <p className="font-medium">Data Sharing</p>
                      <p className="text-sm text-muted-foreground">Allow sharing of usage data to improve services</p>
                    </div>
                    <Switch
                      checked={privacy.dataSharing}
                      onCheckedChange={(checked) => handlePrivacyChange("dataSharing", checked)}
                      className="data-[state=checked]:animate-pulse"
                    />
                  </div>
                </div>
              </div>

              {/* Account Actions */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Account Actions</h3>
                <div className="space-y-4">
                  <Button
                    variant="outline"
                    className="w-full justify-start hover:bg-muted/50 transition-all duration-300"
                  >
                    <SettingsIcon className="mr-2 h-4 w-4" />
                    Export My Data
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start hover:bg-muted/50 transition-all duration-300"
                  >
                    <AlertCircle className="mr-2 h-4 w-4" />
                    Deactivate Account
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10 transition-all duration-300"
                  >
                    <X className="mr-2 h-4 w-4" />
                    Delete Account
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </CardContent>

        <CardFooter className="flex justify-between">
          <p className="text-xs text-muted-foreground">Last updated: March 11, 2025</p>
        </CardFooter>
      </Tabs>
    </Card>
  )
}


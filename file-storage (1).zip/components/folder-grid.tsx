"use client"

import { Edit, Folder, MoreVertical, Trash } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface FolderGridProps {
  folders: any[]
  onDelete?: (id: string) => void
  onEdit?: (folder: any) => void
}

export function FolderGrid({ folders, onDelete, onEdit }: FolderGridProps) {
  if (folders.length === 0) {
    return (
      <div className="text-center py-12">
        <Folder className="mx-auto h-12 w-12 text-muted-foreground" />
        <h3 className="mt-4 text-lg font-medium">No folders found</h3>
        <p className="mt-2 text-sm text-muted-foreground">Create some folders to organize your certificates.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {folders.map((folder) => (
        <Card key={folder.id} className="glass-card hover-lift overflow-hidden rounded-xl border-0">
          <div className="aspect-[4/3] bg-gradient-to-br from-primary/5 to-primary/20 flex items-center justify-center p-4 relative">
            <div className="absolute inset-0 flex items-center justify-center opacity-10">
              <img
                src="/placeholder.svg?height=300&width=200&text=Folder"
                alt={folder.name}
                className="w-full h-full object-cover"
              />
            </div>
            <Folder className="h-24 w-24 text-primary opacity-80" />
          </div>
          <CardContent className="p-5">
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-1">
                <h3 className="font-medium truncate" title={folder.name}>
                  {folder.name}
                </h3>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 rounded-lg">
                    {folder.category}
                  </Badge>
                  <p className="text-xs text-muted-foreground">
                    {folder.count} {folder.count === 1 ? "certificate" : "certificates"}
                  </p>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <MoreVertical className="h-4 w-4" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="rounded-xl">
                  <DropdownMenuItem onClick={() => onEdit?.(folder)} className="cursor-pointer">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive cursor-pointer"
                    onClick={() => onDelete?.(folder.id)}
                  >
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardContent>
          <CardFooter className="p-5 pt-0">
            <Button variant="outline" size="sm" className="w-full rounded-lg">
              <Folder className="mr-2 h-4 w-4" />
              Open Folder
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}


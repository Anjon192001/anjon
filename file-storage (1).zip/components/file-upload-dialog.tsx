"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Upload, CalendarIcon, X, Image, FileUp, File } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, parse } from "date-fns"
import { globalState } from "./admin-dashboard"

interface FileUploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpload: (file: any) => void
}

export function FileUploadDialog({ open, onOpenChange, onUpload }: FileUploadDialogProps) {
  const [fullName, setFullName] = useState("")
  const [fileCategory, setFileCategory] = useState("")
  const [fileDate, setFileDate] = useState<Date | undefined>(new Date())
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [selectedFolder, setSelectedFolder] = useState("")
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [dateInput, setDateInput] = useState("")
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dropAreaRef = useRef<HTMLDivElement>(null)

  // Reset form when dialog closes
  useEffect(() => {
    if (!open) {
      resetForm()
    }
  }, [open])

  // Format date to human-readable format
  const formatDateToHuman = (date: Date) => {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ]
    return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`
  }

  // Parse date from various formats
  const parseDate = (input: string): Date | null => {
    // Try different date formats
    const formats = ["MM/dd/yyyy", "M/d/yyyy", "MM-dd-yyyy", "yyyy-MM-dd", "dd/MM/yyyy", "d/M/yyyy", "dd-MM-yyyy"]

    for (const formatStr of formats) {
      try {
        const parsedDate = parse(input, formatStr, new Date())
        if (!isNaN(parsedDate.getTime())) {
          return parsedDate
        }
      } catch (e) {
        // Continue to next format
      }
    }

    // Try to parse numbers only (assuming MM/DD/YYYY)
    const numbersOnly = input.replace(/\D/g, "")
    if (numbersOnly.length === 8) {
      const month = Number.parseInt(numbersOnly.substring(0, 2))
      const day = Number.parseInt(numbersOnly.substring(2, 4))
      const year = Number.parseInt(numbersOnly.substring(4, 8))

      if (month >= 1 && month <= 12 && day >= 1 && day <= 31 && year >= 1900) {
        return new Date(year, month - 1, day)
      }
    }

    return null
  }

  const handleDateInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value
    setDateInput(input)

    const parsedDate = parseDate(input)
    if (parsedDate) {
      setFileDate(parsedDate)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      processFile(file)
    }
  }

  const processFile = (file: File) => {
    setSelectedFile(file)

    // Create preview URL for image files
    if (file.type.startsWith("image/")) {
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
    } else {
      setPreviewUrl(null)
    }

    // Auto-extract name and date from filename
    const filename = file.name

    // Extract full name
    // Try to extract a name from formats like "Certificate - John Doe.pdf" or "John Doe - Birth Certificate.pdf"
    let extractedName = ""
    const nameParts = filename.split(" - ")
    if (nameParts.length > 1) {
      // Check if the first part looks like a name (not "Certificate" or a category)
      if (
        !nameParts[0].toLowerCase().includes("certificate") &&
        !["birth", "marriage", "death"].some((cat) => nameParts[0].toLowerCase().includes(cat))
      ) {
        extractedName = nameParts[0].replace(/\.[^/.]+$/, "") // First part is the name
      } else {
        extractedName = nameParts[1].replace(/\.[^/.]+$/, "") // Second part is the name

        // Clean up category text if present in the name
        extractedName = extractedName
          .replace(/birth certificate/i, "")
          .replace(/marriage certificate/i, "")
          .replace(/death certificate/i, "")
          .replace(/certificate/i, "")
          .trim()
      }

      setFullName(extractedName)
    }

    // Try to auto-detect category from filename
    const lowercaseFilename = filename.toLowerCase()
    if (lowercaseFilename.includes("birth")) {
      setFileCategory("birth")
    } else if (lowercaseFilename.includes("marriage")) {
      setFileCategory("marriage")
    } else if (lowercaseFilename.includes("death")) {
      setFileCategory("death")
    }

    // Try to extract date from filename
    // Look for common date formats: YYYY-MM-DD, MM-DD-YYYY, DD-MM-YYYY, or written dates
    const dateRegexes = [
      /(\d{4}[-/.]\d{1,2}[-/.]\d{1,2})/, // YYYY-MM-DD
      /(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/, // MM-DD-YYYY or DD-MM-YYYY
      /(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}/i, // Month DD, YYYY
    ]

    let extractedDate: Date | undefined = undefined

    for (const regex of dateRegexes) {
      const match = filename.match(regex)
      if (match && match[1]) {
        try {
          // Try to parse the date
          const dateStr = match[1]
          const parsedDate = parseDate(dateStr)
          if (parsedDate) {
            extractedDate = parsedDate
            break
          }
        } catch (e) {
          // Continue to next regex if parsing fails
          continue
        }
      }
    }

    if (extractedDate) {
      setFileDate(extractedDate)
      setDateInput(formatDateToHuman(extractedDate))
    } else {
      setDateInput(formatDateToHuman(new Date()))
    }
  }

  // Handle drag and drop
  useEffect(() => {
    const dropArea = dropAreaRef.current
    if (!dropArea) return

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      dropArea.classList.add("border-primary")
    }

    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      dropArea.classList.remove("border-primary")
    }

    const handleDrop = (e: DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      dropArea.classList.remove("border-primary")

      if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
        const file = e.dataTransfer.files[0]
        processFile(file)
      }
    }

    dropArea.addEventListener("dragover", handleDragOver)
    dropArea.addEventListener("dragleave", handleDragLeave)
    dropArea.addEventListener("drop", handleDrop)

    return () => {
      dropArea.removeEventListener("dragover", handleDragOver)
      dropArea.removeEventListener("dragleave", handleDragLeave)
      dropArea.removeEventListener("drop", handleDrop)
    }
  }, [])

  const simulateUpload = () => {
    setUploading(true)
    setProgress(0)

    // Simulate progress over 2 seconds
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 5
        if (newProgress >= 100) {
          clearInterval(interval)
          finalizeUpload()
          return 100
        }
        return newProgress
      })
    }, 100)
  }

  const finalizeUpload = () => {
    if (selectedFile && fullName && fileCategory && fileDate) {
      // Format file size
      const size = formatFileSize(selectedFile.size)

      const newFile = {
        id: Date.now().toString(),
        name: selectedFile.name,
        fullName: fullName,
        type: selectedFile.type.startsWith("image/") ? "image" : "pdf",
        category: fileCategory,
        folder: selectedFolder || undefined,
        uploadedBy: "admin",
        uploadedAt: format(fileDate, "yyyy-MM-dd"),
        formattedDate: formatDateToHuman(fileDate),
        thumbnail: previewUrl || "/placeholder.svg?height=80&width=80",
      }

      // Small delay to let the progress bar reach 100%
      setTimeout(() => {
        onUpload(newFile)
        setUploading(false)
      }, 300)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedFile && fullName && fileCategory) {
      simulateUpload()
    }
  }

  const resetForm = () => {
    setFullName("")
    setFileCategory("")
    setFileDate(new Date())
    setSelectedFile(null)
    setSelectedFolder("")
    setUploading(false)
    setProgress(0)
    setDateInput("")
    setPreviewUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) {
      return `${bytes} B`
    } else if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`
    } else {
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    }
  }

  const handleRemoveFile = () => {
    setSelectedFile(null)
    setPreviewUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const getFileIcon = () => {
    if (!selectedFile) return <Upload className="h-8 w-8 text-muted-foreground" />

    if (selectedFile.type.startsWith("image/")) {
      return <Image className="h-8 w-8 text-primary" />
    } else if (selectedFile.type.includes("pdf")) {
      return <File className="h-8 w-8 text-red-500" />
    } else {
      return <FileUp className="h-8 w-8 text-primary" />
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
      }}
    >
      <DialogContent className="sm:max-w-[500px] glass-card border-0 rounded-2xl">
        <DialogHeader>
          <DialogTitle className="gradient-text text-xl">Upload Certificate</DialogTitle>
          <DialogDescription>Upload a new certificate to the system.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            {/* Enhanced File Upload Area */}
            <div className="grid gap-2">
              <Label htmlFor="file" className="text-sm font-medium">
                Select Certificate File
              </Label>
              <div
                ref={dropAreaRef}
                className="border-2 border-dashed border-muted-foreground/25 rounded-xl p-6 transition-colors hover:border-primary/50 cursor-pointer flex flex-col items-center justify-center gap-2 file-upload-area"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="bg-muted rounded-full p-3">{getFileIcon()}</div>

                <div className="text-center">
                  {selectedFile ? (
                    <div className="flex flex-col items-center">
                      <p className="font-medium text-sm">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="mt-2 h-7 text-xs"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleRemoveFile()
                        }}
                      >
                        <X className="h-3 w-3 mr-1" /> Remove
                      </Button>
                    </div>
                  ) : (
                    <>
                      <p className="font-medium">Click to upload or drag & drop</p>
                      <p className="text-xs text-muted-foreground mt-1">Upload your certificate file here</p>
                      <p className="text-xs text-primary mt-2">Supports PDF, JPG, JPEG, PNG</p>
                    </>
                  )}
                </div>

                <input
                  id="file"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleFileChange}
                  className="hidden"
                  ref={fileInputRef}
                  required
                />
              </div>
            </div>

            {selectedFile && (
              <>
                {previewUrl && (
                  <div className="relative border rounded-xl p-2 bg-white">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 h-6 w-6 rounded-full bg-background/80 z-10"
                      onClick={handleRemoveFile}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                    <div className="flex justify-center">
                      <img
                        src={previewUrl || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-[200px] object-contain rounded-lg"
                      />
                    </div>
                  </div>
                )}

                <div className="grid gap-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="fullname" className="text-sm font-medium">
                      Full Name
                    </Label>
                    {fullName && <span className="text-xs text-primary">Auto-detected</span>}
                  </div>
                  <Input
                    id="fullname"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Auto-populated from file name"
                    className="rounded-xl h-12 bg-primary/5 border-primary/20"
                    required
                  />
                </div>

                <div className="grid gap-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="category" className="text-sm font-medium">
                      Category
                    </Label>
                    {fileCategory && <span className="text-xs text-primary">Auto-detected</span>}
                  </div>
                  <Select value={fileCategory} onValueChange={setFileCategory} required>
                    <SelectTrigger id="category" className="rounded-xl h-12">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="birth">Birth Certificate</SelectItem>
                      <SelectItem value="marriage">Marriage Certificate</SelectItem>
                      <SelectItem value="death">Death Certificate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="folder" className="text-sm font-medium">
                    Folder (Optional)
                  </Label>
                  <Select value={selectedFolder} onValueChange={setSelectedFolder}>
                    <SelectTrigger id="folder" className="rounded-xl h-12">
                      <SelectValue placeholder="Select folder" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="root">None (Root folder)</SelectItem>
                      {globalState.folders.map((folder) => (
                        <SelectItem key={folder.id} value={folder.id}>
                          {folder.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="date-input" className="text-sm font-medium">
                      Date
                    </Label>
                    {fileDate && fileDate !== new Date() && <span className="text-xs text-primary">Auto-detected</span>}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      id="date-input"
                      value={dateInput}
                      onChange={handleDateInputChange}
                      placeholder="Enter date (MM/DD/YYYY)"
                      className="rounded-xl h-12 flex-1"
                    />
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="h-12 w-12 rounded-xl p-0">
                          <CalendarIcon className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 rounded-xl">
                        <Calendar
                          mode="single"
                          selected={fileDate}
                          onSelect={(date) => {
                            if (date) {
                              setFileDate(date)
                              setDateInput(formatDateToHuman(date))
                            }
                          }}
                          initialFocus
                          className="rounded-xl"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  {fileDate && (
                    <p className="text-xs text-muted-foreground">
                      Formatted date: <span className="font-medium">{formatDateToHuman(fileDate)}</span>
                    </p>
                  )}
                </div>

                {uploading && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Uploading...</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="w-full h-2 rounded-full" />
                  </div>
                )}
              </>
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={uploading}
              className="rounded-xl"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!selectedFile || !fullName || !fileCategory || !fileDate || uploading}
              className="rounded-xl"
            >
              <Upload className="mr-2 h-4 w-4" />
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


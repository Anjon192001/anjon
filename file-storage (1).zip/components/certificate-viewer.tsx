import { Download, Share, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

interface CertificateViewerProps {
  certificate: {
    id: string
    name: string
    date: string
    location: string
    details: string
    image: string
  }
}

export function CertificateViewer({ certificate }: CertificateViewerProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Left side - Certificate details */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold mb-4">{certificate.name}</h2>

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Date</h3>
              <p>{certificate.date}</p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Location</h3>
              <p>{certificate.location}</p>
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Details</h3>
              <p className="mt-1">{certificate.details}</p>
            </div>
          </div>

          <div className="flex gap-2 mt-6">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
            <Button variant="outline" size="sm">
              <Share className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button variant="outline" size="sm">
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Right side - Certificate image */}
      <div className="bg-white rounded-lg overflow-hidden border shadow-sm">
        <div className="h-full flex items-center justify-center p-4">
          <img
            src={certificate.image || "/placeholder.svg"}
            alt={certificate.name}
            className="max-w-full max-h-[600px] object-contain"
          />
        </div>
      </div>
    </div>
  )
}


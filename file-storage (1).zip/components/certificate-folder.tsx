"use client"

import { Folder } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface CertificateFolderProps {
  folder: {
    id: string
    name: string
    count: number
    thumbnail: string
    description: string
  }
  onClick: () => void
}

export function CertificateFolder({ folder, onClick }: CertificateFolderProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={onClick}>
      <div className="aspect-video bg-muted relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <Folder className="h-20 w-20 text-blue-500 opacity-80" />
        </div>
      </div>
      <CardContent className="p-4">
        <h3 className="text-lg font-medium">{folder.name}</h3>
        <p className="text-sm text-muted-foreground mt-1">{folder.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 text-sm text-muted-foreground">
        {folder.count} {folder.count === 1 ? "certificate" : "certificates"}
      </CardFooter>
    </Card>
  )
}


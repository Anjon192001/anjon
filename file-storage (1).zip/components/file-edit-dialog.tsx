"use client"

import type React from "react"

import { useState } from "react"
import { Save, CalendarIcon } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface FileEditDialogProps {
  file: any
  open: boolean
  onOpenChange: (open: boolean) => void
  onEdit?: (file: any) => void
}

export function FileEditDialog({ file, open, onOpenChange, onEdit }: FileEditDialogProps) {
  const [fileName, setFileName] = useState(file.name)
  const [fullName, setFullName] = useState(file.fullName || file.name.split(" - ")[1]?.replace(".pdf", "") || "")
  const [fileCategory, setFileCategory] = useState(file.category)
  const [fileDate, setFileDate] = useState<Date | undefined>(
    file.uploadedAt ? new Date(file.uploadedAt.replace(/-/g, "/")) : undefined,
  )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (fileName && fullName && fileCategory && fileDate) {
      const formattedDate = format(fileDate, "yyyy-MM-dd")

      const editedFile = {
        ...file,
        name: fileName,
        fullName: fullName,
        category: fileCategory,
        uploadedAt: formattedDate,
      }

      if (onEdit) {
        onEdit(editedFile)
      }

      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] glass-card border-0 rounded-2xl">
        <DialogHeader>
          <DialogTitle className="gradient-text text-xl">Edit Certificate</DialogTitle>
          <DialogDescription>Make changes to the certificate information.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name" className="text-sm font-medium">
                File Name
              </Label>
              <Input
                id="edit-name"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                className="rounded-xl h-12"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-fullname" className="text-sm font-medium">
                Full Name
              </Label>
              <Input
                id="edit-fullname"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Enter person's full name"
                className="rounded-xl h-12"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-category" className="text-sm font-medium">
                Category
              </Label>
              <Select value={fileCategory} onValueChange={setFileCategory} required>
                <SelectTrigger id="edit-category" className="rounded-xl h-12">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  <SelectItem value="birth">Birth Certificate</SelectItem>
                  <SelectItem value="marriage">Marriage Certificate</SelectItem>
                  <SelectItem value="death">Death Certificate</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-date" className="text-sm font-medium">
                Date
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="edit-date"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal rounded-xl h-12",
                      !fileDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {fileDate ? format(fileDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 rounded-xl">
                  <Calendar
                    mode="single"
                    selected={fileDate}
                    onSelect={setFileDate}
                    initialFocus
                    className="rounded-xl"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="rounded-xl">
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!fileName || !fullName || !fileCategory || !fileDate}
              className="rounded-xl"
            >
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


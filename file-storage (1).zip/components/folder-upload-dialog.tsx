"use client"

import type React from "react"

import { useState } from "react"
import { FolderPlus } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface FolderUploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpload: (folder: any) => void
}

export function FolderUploadDialog({ open, onOpenChange, onUpload }: FolderUploadDialogProps) {
  const [folderName, setFolderName] = useState("")
  const [folderCategory, setFolderCategory] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (folderName && folderCategory) {
      const newFolder = {
        id: Date.now().toString(),
        name: folderName,
        count: 0,
        category: folderCategory,
        createdBy: "admin",
        createdAt: new Date().toISOString().split("T")[0],
        thumbnail: "/placeholder.svg?height=80&width=80",
      }

      onUpload(newFolder)
      resetForm()
    }
  }

  const resetForm = () => {
    setFolderName("")
    setFolderCategory("")
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
        if (!open) resetForm()
      }}
    >
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Create New Folder</DialogTitle>
            <DialogDescription>Create a new folder to organize certificates.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="folder-name">Folder Name</Label>
              <Input
                id="folder-name"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Enter folder name"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="folder-category">Category</Label>
              <Select value={folderCategory} onValueChange={setFolderCategory} required>
                <SelectTrigger id="folder-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="birth">Birth Certificates</SelectItem>
                  <SelectItem value="marriage">Marriage Certificates</SelectItem>
                  <SelectItem value="death">Death Certificates</SelectItem>
                  <SelectItem value="other">Other Documents</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!folderName || !folderCategory}>
              <FolderPlus className="mr-2 h-4 w-4" />
              Create Folder
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


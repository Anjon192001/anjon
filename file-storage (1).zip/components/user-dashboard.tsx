"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { LogOut, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { FileGrid } from "@/components/file-grid"
import { globalState } from "@/components/admin-dashboard"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { NotificationCenter } from "@/components/notification-center"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Initialize user data
const userData = {
  username: "MARIO S SABINO JR",
  email: "mariobaldo2001@gmail.com",
  phone: "09756419201",
  address: "p-6 kisolon sumilao bukidnon",
  birthdate: "2001-04-19",
  bio: "",
  profileImage:
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Profile%20picture.jpg-pBicBaxJ72zxuCcxpTiAMOVxyOMk9m.jpeg",
}

export function UserDashboard() {
  const router = useRouter()
  const [files, setFiles] = useState(globalState.files)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [currentFolder, setCurrentFolder] = useState<string | null>(null)
  const [breadcrumbs, setBreadcrumbs] = useState<Array<{ id: string; name: string }>>([])

  // Update files when global state changes
  useEffect(() => {
    const interval = setInterval(() => {
      if (JSON.stringify(files) !== JSON.stringify(globalState.files)) {
        setFiles([...globalState.files])
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [files])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/")
  }

  const handleFolderClick = (folderId: string, folderName: string) => {
    setCurrentFolder(folderId)
    setBreadcrumbs((prev) => [...prev, { id: folderId, name: folderName }])
  }

  const handleBreadcrumbClick = (index: number) => {
    if (index === -1) {
      setCurrentFolder(null)
      setBreadcrumbs([])
    } else {
      setCurrentFolder(breadcrumbs[index].id)
      setBreadcrumbs((prev) => prev.slice(0, index + 1))
    }
  }

  // Filter files based on search query, active tab, and current folder
  const filteredFiles = files.filter((file) => {
    const matchesSearch =
      file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (file.fullName && file.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesCategory = activeTab === "all" || file.category === activeTab
    const matchesFolder = currentFolder ? file.folder === currentFolder : !file.folder
    return matchesSearch && matchesCategory && matchesFolder
  })

  // Get folders for current level
  const currentFolders = globalState.folders.filter((folder) => {
    const matchesSearch = folder.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeTab === "all" || folder.category === activeTab
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-secondary/30">
      {/* Header */}
      <header className="border-b backdrop-blur-md bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-bold gradient-text">SUMILAO MUNICIPAL CIVIL REGISTRAR OFFICE</h1>

          <div className="flex items-center gap-4">
            <NotificationCenter />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10 border-2 border-primary/20">
                    <AvatarImage src={userData.profileImage} alt={userData.username} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {userData.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{userData.username}</p>
                    <p className="text-xs text-muted-foreground">User</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 container mx-auto px-4 py-6">
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search certificates..."
                className="pl-9 w-full h-10 rounded-xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex overflow-x-auto pb-2 gap-2">
            <Button
              variant={activeTab === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("all")}
              className="rounded-xl"
            >
              All Certificates
            </Button>
            <Button
              variant={activeTab === "birth" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("birth")}
              className="rounded-xl"
            >
              Birth Certificates
            </Button>
            <Button
              variant={activeTab === "marriage" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("marriage")}
              className="rounded-xl"
            >
              Marriage Certificates
            </Button>
            <Button
              variant={activeTab === "death" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("death")}
              className="rounded-xl"
            >
              Death Certificates
            </Button>
          </div>

          {/* Breadcrumbs */}
          <div className="flex items-center gap-2 text-sm">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleBreadcrumbClick(-1)}
              className={currentFolder ? "opacity-100" : "opacity-50 cursor-default"}
            >
              Home
            </Button>
            {breadcrumbs.map((crumb, index) => (
              <div key={crumb.id} className="flex items-center gap-2">
                <span>/</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleBreadcrumbClick(index)}
                  className={index === breadcrumbs.length - 1 ? "opacity-50 cursor-default" : ""}
                >
                  {crumb.name}
                </Button>
              </div>
            ))}
          </div>

          <Separator className="my-4" />

          <FileGrid files={filteredFiles} folders={currentFolders} isAdmin={false} onFolderClick={handleFolderClick} />
        </div>
      </div>
    </div>
  )
}


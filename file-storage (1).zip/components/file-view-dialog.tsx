"use client"

import { useState } from "react"
import { Download, Printer, X, Share } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

interface FileViewDialogProps {
  file: any
  open: boolean
  onOpenChange: (open: boolean) => void
}

// Mock globalState for demonstration purposes.  In a real application,
// this would likely come from a context or state management library.
const globalState = {
  folders: [], // Initialize with an empty array or your actual folder data structure
}

export function FileViewDialog({ file, open, onOpenChange }: FileViewDialogProps) {
  const [isImageLoaded, setIsImageLoaded] = useState(false)

  // Handle print functionality - print only the image
  const handlePrint = () => {
    const printWindow = window.open("", "_blank")
    if (printWindow) {
      printWindow.document.write(`
      <html>
        <head>
          <title>Print Certificate</title>
          <style>
            body { 
              margin: 0; 
              padding: 0; 
              display: flex; 
              justify-content: center; 
              align-items: center; 
              min-height: 100vh;
            }
            img { 
              max-width: 100%; 
              max-height: 100vh; 
              object-fit: contain;
            }
            .print-button {
              position: fixed;
              top: 20px;
              right: 20px;
              padding: 10px 20px;
              background: #3b82f6;
              color: white;
              border: none;
              border-radius: 8px;
              cursor: pointer;
              font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              font-weight: 500;
            }
            @media print {
              .print-button { display: none; }
            }
          </style>
        </head>
        <body>
          <button class="print-button" onclick="window.print()">Print</button>
          <img src="${file.thumbnail || "/placeholder.svg?height=800&width=600&text=Certificate"}" />
        </body>
      </html>
    `)
      printWindow.document.close()
      // Automatically trigger print after the image loads
      setTimeout(() => {
        printWindow.print()
      }, 500)
    }
  }

  // Handle download functionality
  const handleDownload = () => {
    // Create a link element
    const link = document.createElement("a")

    // In a real app, this would be the actual file URL
    // For this demo, we'll use the placeholder image or the file's thumbnail
    link.href = file.thumbnail || "/placeholder.svg?height=800&width=600&text=Certificate"

    // Set the download attribute with the file name
    link.download = file.name

    // Append to the document
    document.body.appendChild(link)

    // Trigger the download
    link.click()

    // Clean up
    document.body.removeChild(link)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-auto glass-card border-0 rounded-2xl">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="gradient-text text-xl">{file.fullName}</DialogTitle>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => onOpenChange(false)}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6 mt-4">
          {/* Left side - Certificate details */}
          <div className="space-y-4">
            <div className="p-4 bg-primary/5 rounded-xl">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 rounded-lg">
                  {file.category.charAt(0).toUpperCase() + file.category.slice(1)} Certificate
                </Badge>
                <span className="text-sm text-muted-foreground">ID: {file.id}</span>
              </div>

              <div className="space-y-3">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Full Name</h3>
                  <p className="font-medium text-lg">
                    {file.fullName || file.name.split(" - ")[1]?.replace(".pdf", "") || "John Smith"}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Date</h3>
                  <p>{file.formattedDate || file.uploadedAt}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">File Name</h3>
                  <p className="text-sm truncate" title={file.name}>
                    {file.name}
                  </p>
                </div>

                {file.folder && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Folder</h3>
                    <p className="text-sm">
                      {globalState.folders.find((f) => f.id === file.folder)?.name || "Unknown folder"}
                    </p>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            <div className="flex flex-wrap gap-2">
              <Button onClick={handleDownload} className="rounded-xl flex-1 hover:shadow-lg transition-shadow">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button
                variant="outline"
                onClick={handlePrint}
                className="rounded-xl flex-1 hover:bg-primary hover:text-white transition-colors"
              >
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button
                variant="secondary"
                className="rounded-xl flex-1 hover:bg-secondary-foreground hover:text-secondary transition-colors"
              >
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
          </div>

          {/* Right side - Certificate preview */}
          <div className="bg-white rounded-xl overflow-hidden border shadow-md flex items-center justify-center p-4 certificate-frame">
            <div className="relative w-full h-full min-h-[400px] flex items-center justify-center">
              {!isImageLoaded && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted">
                  <div className="flex flex-col items-center">
                    <svg
                      className="animate-spin h-8 w-8 text-primary"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    <p className="mt-2 text-sm text-muted-foreground">Loading certificate...</p>
                  </div>
                </div>
              )}
              <img
                src={file.thumbnail || "/placeholder.svg?height=800&width=600&text=Certificate+Document"}
                alt={`${file.category} certificate for ${file.fullName || "person"}`}
                className="max-w-full max-h-[500px] object-contain"
                onLoad={() => setIsImageLoaded(true)}
              />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}


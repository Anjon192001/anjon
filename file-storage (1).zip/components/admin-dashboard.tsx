"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { File, FolderPlus, LogOut, Search, Upload, Folder, Settings, User, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileUploadDialog } from "@/components/file-upload-dialog"
import { FileGrid } from "@/components/file-grid"
import { UserManagement } from "@/components/user-management"
import { FolderUploadDialog } from "@/components/folder-upload-dialog"
import { FolderGrid } from "@/components/folder-grid"
import { FolderEditDialog } from "@/components/folder-edit-dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { NotificationCenter } from "@/components/notification-center"
import { UserProfile } from "@/components/user-profile"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

// Add this at the top after the imports, before the initialFiles definition
// Create a shared state object to simulate backend storage
export const globalState = {
  files: [
    {
      id: "1",
      name: "Birth Certificate - John Smith.pdf",
      fullName: "John Smith",
      type: "pdf",
      category: "birth",
      uploadedBy: "admin",
      uploadedAt: "2023-10-15",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
    {
      id: "2",
      name: "Marriage Certificate - Johnson Family.pdf",
      fullName: "Johnson Family",
      type: "pdf",
      category: "marriage",
      uploadedBy: "admin",
      uploadedAt: "2023-10-14",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
    {
      id: "3",
      name: "Death Certificate - Robert Davis.pdf",
      fullName: "Robert Davis",
      type: "pdf",
      category: "death",
      uploadedBy: "admin",
      uploadedAt: "2023-10-12",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
    {
      id: "4",
      name: "Birth Certificate - Emma Wilson.pdf",
      fullName: "Emma Wilson",
      type: "pdf",
      category: "birth",
      uploadedBy: "admin",
      uploadedAt: "2023-10-10",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
  ],
  folders: [
    {
      id: "f1",
      name: "Birth Certificates",
      count: 2,
      category: "birth",
      createdBy: "admin",
      createdAt: "2023-10-01",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
    {
      id: "f2",
      name: "Marriage Certificates",
      count: 1,
      category: "marriage",
      createdBy: "admin",
      createdAt: "2023-10-02",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
    {
      id: "f3",
      name: "Death Certificates",
      count: 1,
      category: "death",
      createdBy: "admin",
      createdAt: "2023-10-03",
      thumbnail: "/placeholder.svg?height=80&width=80",
    },
  ],
  updateFiles: function (newFiles: any[]) {
    this.files = newFiles
  },
  updateFolders: function (newFolders: any[]) {
    this.folders = newFolders
  },
}

export function AdminDashboard() {
  const router = useRouter()
  const [files, setFiles] = useState(globalState.files)
  const [folders, setFolders] = useState(globalState.folders)
  const [searchQuery, setSearchQuery] = useState("")
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [isFolderUploadOpen, setIsFolderUploadOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const [viewMode, setViewMode] = useState("folders") // "folders" or "files"
  const [username, setUsername] = useState("MARIO S SABINO JR")
  const [selectedFolder, setSelectedFolder] = useState<any | null>(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    // Get username from localStorage
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      const user = JSON.parse(currentUser)
      setUsername(user.username)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/")
  }

  // Update the handleUpload function to include the date in the format we need
  const handleUpload = (newFile: any) => {
    const updatedFiles = [newFile, ...files]
    setFiles(updatedFiles)
    // Update global state to sync with user view
    globalState.updateFiles(updatedFiles)
    setIsUploadOpen(false)
  }

  // Add a function to handle file edits
  const handleEditFile = (editedFile: any) => {
    const updatedFiles = files.map((file) => (file.id === editedFile.id ? editedFile : file))
    setFiles(updatedFiles)
    // Update global state
    globalState.updateFiles(updatedFiles)
  }

  const handleFolderUpload = (newFolder: any) => {
    const updatedFolders = [newFolder, ...folders]
    setFolders(updatedFolders)
    // Update global state
    globalState.updateFolders(updatedFolders)
    setIsFolderUploadOpen(false)
  }

  const handleDeleteFile = (fileId: string) => {
    const updatedFiles = files.filter((file) => file.id !== fileId)
    setFiles(updatedFiles)
    // Update global state
    globalState.updateFiles(updatedFiles)
  }

  const handleDeleteFolder = (folderId: string) => {
    const updatedFolders = folders.filter((folder) => folder.id !== folderId)
    setFolders(updatedFolders)
    // Update global state
    globalState.updateFolders(updatedFolders)
  }

  const handleEditFolder = (editedFolder: any) => {
    const updatedFolders = folders.map((folder) => (folder.id === editedFolder.id ? editedFolder : folder))
    setFolders(updatedFolders)
    // Update global state
    globalState.updateFolders(updatedFolders)
    setSelectedFolder(null)
  }

  // Filter files based on search query and active tab
  const filteredFiles = files.filter((file) => {
    const matchesSearch =
      file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (file.fullName && file.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesCategory = activeTab === "all" || file.category === activeTab
    return matchesSearch && matchesCategory
  })

  // Filter folders based on search query and active tab
  const filteredFolders = folders.filter((folder) => {
    const matchesSearch = folder.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeTab === "all" || folder.category === activeTab
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-secondary/30">
      {/* Header */}
      <header className="border-b backdrop-blur-md bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[240px] sm:w-[300px]">
                <div className="py-4">
                  <h2 className="text-lg font-bold mb-6 gradient-text">SUMILAO MUNICIPAL CIVIL REGISTRAR OFFICE</h2>
                  <nav className="space-y-2">
                    <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("all")}>
                      <File className="mr-2 h-4 w-4" />
                      All Certificates
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("birth")}>
                      <File className="mr-2 h-4 w-4" />
                      Birth Certificates
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("marriage")}>
                      <File className="mr-2 h-4 w-4" />
                      Marriage Certificates
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("death")}>
                      <File className="mr-2 h-4 w-4" />
                      Death Certificates
                    </Button>
                    <Separator className="my-4" />
                    <Button variant="ghost" className="w-full justify-start" onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </Button>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-bold hidden md:block gradient-text">
              SUMILAO MUNICIPAL CIVIL REGISTRAR OFFICE
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <NotificationCenter />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10 border-2 border-primary/20">
                    <AvatarImage
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Profile%20picture.jpg-pBicBaxJ72zxuCcxpTiAMOVxyOMk9m.jpeg"
                      alt={username}
                    />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{username}</p>
                    <p className="text-xs text-muted-foreground">Administrator</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 container mx-auto px-4 py-6">
        <Tabs defaultValue="files" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <TabsList className="rounded-xl p-1">
              <TabsTrigger value="files" className="rounded-lg">
                Certificates
              </TabsTrigger>
              <TabsTrigger value="users" className="rounded-lg">
                Users
              </TabsTrigger>
              <TabsTrigger value="profile" className="rounded-lg">
                Profile
              </TabsTrigger>
              <TabsTrigger value="settings" className="rounded-lg">
                Settings
              </TabsTrigger>
            </TabsList>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search certificates..."
                  className="pl-9 w-full h-10 rounded-xl"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Button onClick={() => setIsUploadOpen(true)} className="rounded-xl h-10">
                <Upload className="h-4 w-4 mr-2" />
                Upload
              </Button>

              <Button variant="outline" onClick={() => setIsFolderUploadOpen(true)} className="rounded-xl h-10">
                <FolderPlus className="h-4 w-4 mr-2" />
                New Folder
              </Button>
            </div>
          </div>

          <TabsContent value="files" className="space-y-6">
            <div className="flex overflow-x-auto pb-2 gap-2">
              <Button
                variant={activeTab === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab("all")}
                className="rounded-xl"
              >
                All Certificates
              </Button>
              <Button
                variant={activeTab === "birth" ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab("birth")}
                className="rounded-xl"
              >
                Birth Certificates
              </Button>
              <Button
                variant={activeTab === "marriage" ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab("marriage")}
                className="rounded-xl"
              >
                Marriage Certificates
              </Button>
              <Button
                variant={activeTab === "death" ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab("death")}
                className="rounded-xl"
              >
                Death Certificates
              </Button>
            </div>

            <div className="flex justify-end">
              <div className="flex border rounded-xl overflow-hidden">
                <Button
                  variant={viewMode === "folders" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-none"
                  onClick={() => setViewMode("folders")}
                >
                  <Folder className="h-4 w-4 mr-2" />
                  Folders
                </Button>
                <Button
                  variant={viewMode === "files" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-none"
                  onClick={() => setViewMode("files")}
                >
                  <File className="h-4 w-4 mr-2" />
                  Files
                </Button>
              </div>
            </div>

            <Separator className="my-4" />

            {viewMode === "folders" ? (
              <FolderGrid
                folders={filteredFolders}
                onDelete={handleDeleteFolder}
                onEdit={(folder) => setSelectedFolder(folder)}
              />
            ) : (
              <FileGrid files={filteredFiles} onDelete={handleDeleteFile} onEdit={handleEditFile} isAdmin={true} />
            )}
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          <TabsContent value="profile">
            <UserProfile username={username} role="admin" />
          </TabsContent>

          <TabsContent value="settings">
            <div className="max-w-2xl mx-auto glass-card rounded-2xl p-6">
              <h2 className="text-xl font-bold mb-4 gradient-text">System Settings</h2>
              <p className="text-muted-foreground mb-6">
                Configure system-wide settings for the SUMILAO MUNICIPAL CIVIL REGISTRAR OFFICE.
              </p>

              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="font-medium">Storage Settings</h3>
                  <div className="grid gap-4">
                    <div className="flex items-center justify-between">
                      <span>Maximum file size</span>
                      <span className="font-medium">10 MB</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Allowed file types</span>
                      <span className="font-medium">PDF, JPG, PNG</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Storage used</span>
                      <div className="flex items-center">
                        <span className="font-medium mr-2">45.2 MB / 1 GB</span>
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          4.5%
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h3 className="font-medium">Security Settings</h3>
                  <div className="grid gap-4">
                    <div className="flex items-center justify-between">
                      <span>Two-factor authentication</span>
                      <Button variant="outline" size="sm" className="h-8 rounded-lg">
                        Enable
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Session timeout</span>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">30 minutes</span>
                        <Button variant="ghost" size="sm" className="h-8 rounded-lg">
                          Change
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Last login</span>
                      <span className="text-muted-foreground">Today, 10:42 AM</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <FileUploadDialog open={isUploadOpen} onOpenChange={setIsUploadOpen} onUpload={handleUpload} />

      <FolderUploadDialog
        open={isFolderUploadOpen}
        onOpenChange={setIsFolderUploadOpen}
        onUpload={handleFolderUpload}
      />

      {selectedFolder && (
        <FolderEditDialog
          folder={selectedFolder}
          open={!!selectedFolder}
          onOpenChange={(open) => !open && setSelectedFolder(null)}
          onSave={handleEditFolder}
        />
      )}
    </div>
  )
}


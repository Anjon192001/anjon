import { File, FileImage, FileSpreadsheet, FileText, FileType, Folder, MoreVertical } from "lucide-react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"

interface FileCardProps {
  name: string
  type: string
  thumbnail?: string
  metadata?: string
}

export function FileCard({ name, type, thumbnail, metadata }: FileCardProps) {
  const getIcon = () => {
    switch (type) {
      case "folder":
        return <Folder className="h-8 w-8 text-blue-500" />
      case "image":
        return <FileImage className="h-8 w-8 text-green-500" />
      case "pdf":
        return <FileText className="h-8 w-8 text-red-500" />
      case "spreadsheet":
        return <FileSpreadsheet className="h-8 w-8 text-emerald-500" />
      case "presentation":
        return <FileType className="h-8 w-8 text-orange-500" />
      default:
        return <File className="h-8 w-8 text-gray-500" />
    }
  }

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <CardHeader className="p-0">
        <div className="relative pt-[75%] bg-muted">
          {type === "image" ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <img src={thumbnail || "/placeholder.svg"} alt={name} className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">{getIcon()}</div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-3">
        <div className="flex items-start justify-between">
          <div className="truncate pr-2">
            <p className="font-medium truncate" title={name}>
              {name}
            </p>
            <p className="text-xs text-muted-foreground">{metadata}</p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
                <span className="sr-only">Open menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Download</DropdownMenuItem>
              <DropdownMenuItem>Rename</DropdownMenuItem>
              <DropdownMenuItem>Share</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from "react"
import { Search, Upload, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CertificateFolder } from "@/components/certificate-folder"
import { CertificateViewer } from "@/components/certificate-viewer"

// Sample certificate folders
const certificateFolders = [
  {
    id: "birth",
    name: "Birth Certificates",
    count: 5,
    thumbnail: "/placeholder.svg?height=80&width=80",
    description: "Official documents certifying an individual's birth details including date, place, and parentage.",
  },
  {
    id: "marriage",
    name: "Marriage Certificates",
    count: 3,
    thumbnail: "/placeholder.svg?height=80&width=80",
    description:
      "Legal documents that prove two individuals are married, including the date and location of the ceremony.",
  },
  {
    id: "death",
    name: "Death Certificates",
    count: 2,
    thumbnail: "/placeholder.svg?height=80&width=80",
    description: "Official records that document the date, location, and cause of an individual's death.",
  },
]

// Sample certificates for each folder
const certificateData = {
  birth: [
    {
      id: "b1",
      name: "John Smith Birth Certificate",
      date: "January 15, 1985",
      location: "Memorial Hospital, Chicago, IL",
      details: "Born to parents Mary and Robert Smith. Weight: 7lbs 6oz. Time of birth: 3:45 PM.",
      image: "/placeholder.svg?height=400&width=300",
    },
    {
      id: "b2",
      name: "Emma Johnson Birth Certificate",
      date: "March 22, 1990",
      location: "St. Luke's Hospital, New York, NY",
      details: "Born to parents Sarah and Michael Johnson. Weight: 6lbs 9oz. Time of birth: 10:15 AM.",
      image: "/placeholder.svg?height=400&width=300",
    },
  ],
  marriage: [
    {
      id: "m1",
      name: "Smith-Johnson Marriage Certificate",
      date: "June 12, 2010",
      location: "Central Park, New York, NY",
      details:
        "Marriage of Robert Smith and Jennifer Johnson. Officiated by Rev. James Wilson. Witnesses: Mark Davis and Lisa Brown.",
      image: "/placeholder.svg?height=400&width=300",
    },
    {
      id: "m2",
      name: "Garcia-Martinez Marriage Certificate",
      date: "September 5, 2015",
      location: "St. Patrick's Cathedral, Chicago, IL",
      details:
        "Marriage of Carlos Garcia and Maria Martinez. Officiated by Father Thomas Rodriguez. Witnesses: Juan Lopez and Ana Sanchez.",
      image: "/placeholder.svg?height=400&width=300",
    },
  ],
  death: [
    {
      id: "d1",
      name: "William Brown Death Certificate",
      date: "November 30, 2018",
      location: "Memorial Hospital, Boston, MA",
      details: "Passed away at age 78. Cause of death: Natural causes. Survived by wife Elizabeth and three children.",
      image: "/placeholder.svg?height=400&width=300",
    },
    {
      id: "d2",
      name: "Margaret Wilson Death Certificate",
      date: "February 15, 2020",
      location: "Cedar Nursing Home, Seattle, WA",
      details:
        "Passed away at age 92. Cause of death: Natural causes. Survived by two children and five grandchildren.",
      image: "/placeholder.svg?height=400&width=300",
    },
  ],
}

export function CertificateStorage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null)
  const [selectedCertificate, setSelectedCertificate] = useState<any | null>(null)

  // Filter folders based on search query
  const filteredFolders = certificateFolders.filter((folder) =>
    folder.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Get certificates for the selected folder
  const certificates = selectedFolder ? certificateData[selectedFolder as keyof typeof certificateData] : []

  // Handle folder click
  const handleFolderClick = (folderId: string) => {
    setSelectedFolder(folderId)
    setSelectedCertificate(null)
  }

  // Handle certificate click
  const handleCertificateClick = (certificate: any) => {
    setSelectedCertificate(certificate)
  }

  // Handle back button click
  const handleBackClick = () => {
    if (selectedCertificate) {
      setSelectedCertificate(null)
    } else {
      setSelectedFolder(null)
    }
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <header className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-2xl font-bold">Certificate Storage</h1>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search certificates..."
              className="pl-8 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Button>
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>

          <Button variant="outline" size="icon">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Breadcrumb navigation */}
      {(selectedFolder || selectedCertificate) && (
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={handleBackClick} className="h-8 px-2">
            Back
          </Button>
          <span className="text-muted-foreground">
            {selectedFolder && !selectedCertificate && certificateFolders.find((f) => f.id === selectedFolder)?.name}
            {selectedCertificate &&
              `${certificateFolders.find((f) => f.id === selectedFolder)?.name} / ${selectedCertificate.name}`}
          </span>
        </div>
      )}

      {/* Main content area */}
      <div>
        {/* Show folders when no folder is selected */}
        {!selectedFolder && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredFolders.map((folder) => (
              <CertificateFolder key={folder.id} folder={folder} onClick={() => handleFolderClick(folder.id)} />
            ))}
          </div>
        )}

        {/* Show certificates when a folder is selected but no certificate is selected */}
        {selectedFolder && !selectedCertificate && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certificates.map((certificate) => (
              <div
                key={certificate.id}
                className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleCertificateClick(certificate)}
              >
                <div className="aspect-[4/3] bg-muted">
                  <img
                    src={certificate.image || "/placeholder.svg"}
                    alt={certificate.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium truncate">{certificate.name}</h3>
                  <p className="text-sm text-muted-foreground">{certificate.date}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Show certificate details when a certificate is selected */}
        {selectedCertificate && <CertificateViewer certificate={selectedCertificate} />}
      </div>
    </div>
  )
}


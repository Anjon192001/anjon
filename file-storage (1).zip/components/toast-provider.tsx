"use client"

import { useEffect, useState } from "react"
import { createPortal } from "react-dom"
import { Toast, ToastTitle, ToastDescription } from "@/components/ui/toast"
import useToast from "@/hooks/use-toast"

export function ToastProvider() {
  const { toasts, dismiss } = useToast()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return createPortal(
    <div className="fixed top-0 right-0 z-[100] flex flex-col gap-2 p-4 max-w-[420px] w-full">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`transform transition-all duration-300 ${
            toast.visible ? "translate-x-0 opacity-100" : "translate-x-full opacity-0"
          }`}
        >
          <Toast variant={toast.variant} onClose={() => dismiss(toast.id)}>
            <div>
              <ToastTitle>{toast.title}</ToastTitle>
              {toast.description && <ToastDescription>{toast.description}</ToastDescription>}
            </div>
          </Toast>
        </div>
      ))}
    </div>,
    document.body,
  )
}


"use client"

import { useState } from "react"
import { Bell, Check, X } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

// Sample notifications
const initialNotifications = [
  {
    id: "1",
    title: "New Certificate Uploaded",
    message: "A new birth certificate has been uploaded by admin.",
    time: "5 minutes ago",
    read: false,
  },
  {
    id: "2",
    title: "System Update",
    message: "The system will undergo maintenance on March 15, 2025.",
    time: "2 hours ago",
    read: false,
  },
  {
    id: "3",
    title: "User Account Created",
    message: "A new user account has been created for Maria Santos.",
    time: "Yesterday",
    read: true,
  },
  {
    id: "4",
    title: "Certificate Request",
    message: "John Doe has requested a copy of his birth certificate.",
    time: "2 days ago",
    read: true,
  },
]

export function NotificationCenter() {
  const [notifications, setNotifications] = useState(initialNotifications)
  const [open, setOpen] = useState(false)

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const removeNotification = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const clearAllNotifications = () => {
    setNotifications([])
  }

  // Add a new notification (for demo purposes)
  const addNotification = () => {
    const newNotification = {
      id: Date.now().toString(),
      title: "New Notification",
      message: "This is a new notification that was just created.",
      time: "Just now",
      read: false,
    }

    setNotifications([newNotification, ...notifications])
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative rounded-full">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 h-4 w-4 rounded-full bg-primary text-[10px] font-medium text-primary-foreground flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 rounded-xl" align="end">
        <div className="flex items-center justify-between p-4">
          <div className="font-medium">Notifications</div>
          <div className="flex gap-1">
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={markAllAsRead}>
                Mark all as read
              </Button>
            )}
            {notifications.length > 0 && (
              <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={clearAllNotifications}>
                Clear all
              </Button>
            )}
          </div>
        </div>
        <Separator />
        <ScrollArea className="h-[300px]">
          {notifications.length > 0 ? (
            <div className="space-y-1 p-2">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={cn(
                    "flex gap-2 rounded-lg p-2 transition-colors hover:bg-muted",
                    notification.read ? "opacity-80" : "bg-primary/5",
                  )}
                >
                  <div
                    className={cn(
                      "mt-1 h-2 w-2 rounded-full",
                      notification.read ? "bg-muted-foreground" : "bg-primary",
                    )}
                  />
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{notification.title}</p>
                      <div className="flex items-center gap-1">
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => markAsRead(notification.id)}
                          >
                            <Check className="h-3 w-3" />
                            <span className="sr-only">Mark as read</span>
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeNotification(notification.id)}
                        >
                          <X className="h-3 w-3" />
                          <span className="sr-only">Remove</span>
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{notification.message}</p>
                    <p className="text-xs text-muted-foreground">{notification.time}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex h-full items-center justify-center">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">No notifications</p>
              </div>
            </div>
          )}
        </ScrollArea>
        <Separator />
        <div className="p-2">
          <Button variant="outline" size="sm" className="w-full" onClick={addNotification}>
            Add Test Notification
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}

